var _0x4706 = ['create', 'send', 'pageview', 'set', 'UA-5814682-1', 'pushState', 'undefined', 'Page', 'Url', 'Browser\x20does\x20not\x20support\x20HTML5.', 'log', 'state', 'index', 'index.htm', 'replaceState', 'type1', 'type2', 'type3', 'type4', '.preloader', 'easeInOut', 'remove', 'innerWidth', 'innerHeight', 'WELCOME TO branDPull Services', 'Branding\x20And\x20Marketing', 'GRAPHIC\x20DESIGNING', 'WEB\x20DEVELOPMENT', 'LEGAL\x20SUPPORT', 'BRAND\x20EXPANSION', '.slides\x20.slide', '#bg-wrap,.introdiv', 'html', 'pan-down', 'fromTo', '.playbtn', '900px', '-50%', 'click', 'fadeOut', 'fast', '.skipbtn', 'fadeIn', 'slow', '#introvid', 'get', 'play', '.introdiv', 'ended', '.coverlay\x20h3', '.coverlay\x20.sctext', '.sctwrapper', '.sprev', '.content', 'touch', 'swipeUp', 'swipeDown', '.bullets\x20ul\x20li', 'addClass', 'active', 'removeClass', '.vertext', 'text', '%\x20at\x2050%\x20100%)', 'circle(', 'hide', 'find', '.slidecontent\x20h2\x20.hrow\x20span', '.slidecontent\x20.sdesc,.cta', '.slidecontent\x20.ssection\x20.tx', '.slidebg', 'easeOut', 'siblings', '%\x20at\x2050%\x200%)', 'css', 'circle(0%\x20at\x2050%\x20', 'show', 'attr', 'rel', '.header\x20.logo', '.lineo,.vertext', 'dark', '.slidecontent', '.ssection\x20.tx', '.ssection', 'append', '<span\x20class=\x22blok\x22></span>', '0%\x2050%', 'h2\x20.hrow\x20span', 'length', '.sdesc', '.cta', 'a.cta', '.htm', 'preventDefault', '.transitionmask\x20img,.transitionmask\x20img', '-100%', '.beech-ka', '.beech-ka\x20img', '.transitionmask\x20img', '.inner', 'about\x20websites\x20virtual_reality\x20motion_graphics\x20mobile_apps\x20digital_marketing\x20corporate_identity', '.inner-close', 'ajax', 'POST', '.html', 'John', 'Boston', 'done', 'back', '.inright:eq(0)\x20h3,.inright:eq(0)\x20h4,.inright:eq(0)\x20p', 'scale(1)', '.innerswipe_base', 'start', 'staggerTo', '.seq_anim', '.inner-work-close', 'work.php', '.inner-work', 'masonry', '.grid-item', '.grid-sizer', 'imagesLoaded', 'progress', 'data-id', 'data-name', '/casestudies.htm', 'Case\x20Studies', '.inner-work\x20h2', '.inner-work\x20h3', '+=30', 'toggleClass', '.menulinx\x20ul\x20li', 'open', 'casestudies', 'websites', 'virtual_reality', 'mobile_apps', 'digital_marketing', 'corporate_identity', 'enquire', 'about', '.close_contact,.contactpopupbg', '.contactpopupbg', 'delay', '/enquire.htm', 'Contact\x20us', '.contactpopup', '.cfsubmit', '.er_fname,.er_email', 'input[name=f_name]', 'val', 'input[name=f_email]', 'test', 'Please\x20enter\x20a\x20valid\x20name', '.er_email', 'Please\x20enter\x20your\x20email', 'form.cf', 'serializeArray', 'process_contact.php', 'success', 'reset', '.tymsg', '.inner-detail-close', '-50px', '.workmask', '.detailmask', '.inner-detail', 'casestudies.htm?client=', 'work-detail.php', '.detail-overview-img\x20.swiper-container', 'horizontal', 'cube', 'ready', 'easeNone', '360deg', 'load', 'getScript', '//www.google-analytics.com/analytics.js', 'push'];
(function(_0x1931a4, _0x419a82) {
    var _0x290fc5 = function(_0x55af41) {
        while (--_0x55af41) {
            _0x1931a4['push'](_0x1931a4['shift']());
        }
    };
    _0x290fc5(++_0x419a82);
}(_0x4706, 0xad));
var _0x3c3b = function(_0x22f43c, _0x180dc5) {
    _0x22f43c = _0x22f43c - 0x0;
    var _0x2c9859 = _0x4706[_0x22f43c];
    return _0x2c9859;
};
$(document)[_0x3c3b('0x0')](function() {
    TweenMax['to']($('.preloader\x20img'), 0x3, {
        'ease': Linear[_0x3c3b('0x1')],
        'rotation': _0x3c3b('0x2'),
        'repeat': -0x1
    });
});
$(window)['on'](_0x3c3b('0x3'), function() {
    function _0x1726a8(_0x4f2fcd) {
        $[_0x3c3b('0x4')](_0x3c3b('0x5'));
        window['ga'] = window['ga'] || function() {
            (ga['q'] = ga['q'] || [])[_0x3c3b('0x6')](arguments);
        };
        ga['l'] = +new Date();
        ga(_0x3c3b('0x7'), _0x4f2fcd, 'auto');
        ga(_0x3c3b('0x8'), _0x3c3b('0x9'));
    }

    function _0x3cd839(_0x16a013, _0x6fdd45) {
        ga(_0x3c3b('0xa'), {
            'page': _0x16a013,
            'title': _0x6fdd45
        });
        ga(_0x3c3b('0x8'), _0x3c3b('0x9'));
    }
    _0x1726a8(_0x3c3b('0xb'));
    var _0x49f127 = '';

    function _0x1efd65(_0x25788a, _0x2e8839) {
        if (typeof history[_0x3c3b('0xc')] != _0x3c3b('0xd')) {
            var _0x3b8c1d = {
                'Page': _0x25788a,
                'Url': _0x2e8839
            };
            history[_0x3c3b('0xc')](_0x3b8c1d, _0x3b8c1d[_0x3c3b('0xe')], _0x3b8c1d[_0x3c3b('0xf')]);
        } else {
            alert(_0x3c3b('0x10'));
        }
    }
    $(window)['on']('popstate', function(_0x1e8951) {
        console[_0x3c3b('0x11')]('POPstatetype\x20is\x20' + _0x49f127);
        var _0x3c783b = _0x1e8951['originalEvent'][_0x3c3b('0x12')];
        if (_0x3c783b !== null) {
            console[_0x3c3b('0x11')](_0x3c783b);
        } else {}
        _0x19bc45();
    });
    console[_0x3c3b('0x11')](history);
    var _0x250c77 = {
        'Page': _0x3c3b('0x13'),
        'Url': _0x3c3b('0x14')
    };
    history[_0x3c3b('0x15')](_0x250c77, _0x250c77[_0x3c3b('0xe')], _0x250c77[_0x3c3b('0xf')]);

    function _0x19bc45() {
        console[_0x3c3b('0x11')]('managestatetype\x20is\x20' + _0x49f127);
        if (_0x49f127 == _0x3c3b('0x16')) {
            _0x278d5d();
            _0x49f127 = '';
        } else if (_0x49f127 == _0x3c3b('0x17')) {
            _0x1cc9fe();
            _0x49f127 = '';
        } else if (_0x49f127 == _0x3c3b('0x18')) {
            _0x1755cc();
            _0x49f127 = '';
        } else if (_0x49f127 == _0x3c3b('0x19')) {
            _0x17d1c8();
            _0x49f127 = _0x3c3b('0x17');
        }
    }
    TweenMax['to']($(_0x3c3b('0x1a')), 0.5, {
        'ease': Power4[_0x3c3b('0x1b')],
        'opacity': 0x0,
        'onComplete': function() {
            $(_0x3c3b('0x1a'))[_0x3c3b('0x1c')]();
        }
    });
    var _0x5074e4 = $(window)[_0x3c3b('0x1d')]();
    var _0x44e456 = $(window)[_0x3c3b('0x1e')]();
    var _0x2504d4 = _0x5074e4 < 0x2f8 ? 0x1 : 0x0;
    var _0x3a2e45 = 0x64;
    var _0xbb05bc = 0x0;
    var _0xacb126 = 0x8;
    var _0x37a7aa, _0x3787f5;
    var _0x276c4b = 0x0;
    var _0x3ac83a = 0x7a;
    var _0x58d1cc = [_0x3c3b('0x1f'), _0x3c3b('0x20'), 'DIGITAL\x20MARKETING', _0x3c3b('0x21'), _0x3c3b('0x22'), _0x3c3b('0x23'), 'PHOTOGRAPHY&\x20VIDEOGRAPHY', _0x3c3b('0x24')];
    _0x37a7aa = $(_0x3c3b('0x25'))['eq'](0x0);
    if (_0x2504d4) {
        $(_0x3c3b('0x26'))[_0x3c3b('0x1c')]();
        _0x3ac83a = 0x48;
        _0x255b3c();
    }
    var _0xfe739f = 0x0;
    var _0x3bb6be = 0x0;
    $(_0x3c3b('0x27'))['css']({
        'touch-action': _0x3c3b('0x28')
    });
    TweenMax[_0x3c3b('0x29')]($(_0x3c3b('0x2a')), 0.5, {
        'opacity': 0x0,
        'y': _0x3c3b('0x2b')
    }, {
        'opacity': 0x1,
        'y': _0x3c3b('0x2c')
    });
    $(_0x3c3b('0x2a'))['on'](_0x3c3b('0x2d'), function() {
        $(this)[_0x3c3b('0x2e')](_0x3c3b('0x2f'));
        $(_0x3c3b('0x30'))[_0x3c3b('0x31')](_0x3c3b('0x32'));
        $(_0x3c3b('0x33'))[_0x3c3b('0x34')](0x0)[_0x3c3b('0x35')]();
    });
    $(_0x3c3b('0x30'))['on'](_0x3c3b('0x2d'), function() {
        $(this)['fadeOut'](_0x3c3b('0x2f'));
        $(_0x3c3b('0x36'))[_0x3c3b('0x2e')](_0x3c3b('0x2f'), function() {
            $(this)[_0x3c3b('0x1c')]();
            _0x255b3c();
        });
    });
    $(_0x3c3b('0x33'))['on'](_0x3c3b('0x37'), function() {
        $('.introdiv')['fadeOut'](_0x3c3b('0x2f'), function() {
            $(this)[_0x3c3b('0x1c')]();
            _0x255b3c();
        });
    });

    function _0x255b3c() {
        TweenMax['to']($(_0x3c3b('0x38')), 0.5, {
            'opacity': 0x1,
            'y': '0'
        });
        TweenMax['to']($(_0x3c3b('0x39')), 0.5, {
            'opacity': 0x1,
            'y': '0',
            'delay': 0.4
        });
        setInterval(function() {
            _0x18f80b();
        }, 0x9c4);
    }

    function _0x18f80b() {
        if (_0x276c4b == 0x5) {
            _0x276c4b = 0x0;
            TweenMax[_0x3c3b('0xa')]($(_0x3c3b('0x3a')), {
                'y': 0x0
            });
        }
        _0x276c4b++;
        var _0x57c750 = -0x1 * (_0x276c4b * _0x3ac83a);
        TweenMax['to']($('.sctwrapper'), 0.6, {
            'y': _0x57c750
        });
    }
    $(_0x3c3b('0x3b'))['on'](_0x3c3b('0x2d'), _0x1509c1);
    $('.snext')['on'](_0x3c3b('0x2d'), _0x3d72b6);
    $(_0x3c3b('0x3c'))['scrollsteps']({
        'up': _0x1509c1,
        'down': _0x3d72b6,
        'transitionDuration': 0x7d0,
        'quietPeriodBetweenTwoScrollEvents': 0x5dc
    });
    var _0x2f5ea5 = $(_0x3c3b('0x3c'));
    _0x2f5ea5[_0x3c3b('0x3d')]();
    _0x2f5ea5['on'](_0x3c3b('0x3e'), _0x3d72b6);
    _0x2f5ea5['on'](_0x3c3b('0x3f'), _0x1509c1);
    if (_0x2504d4) {
        _0x3a2e45 = 0x82;
    }

    function _0x3d72b6() {
        if (_0xbb05bc == _0xacb126 - 0x1) _0xbb05bc = -0x1;
        _0xbb05bc++;
        $(_0x3c3b('0x40'))['eq'](_0xbb05bc)[_0x3c3b('0x41')](_0x3c3b('0x42'))['siblings']()[_0x3c3b('0x43')](_0x3c3b('0x42'));
        _0x3787f5 = $(_0x3c3b('0x25'))['eq'](_0xbb05bc);
        _0x341cf6(_0x3787f5, 0x1);
        _0x25de6b(_0x3787f5);
        $(_0x3c3b('0x44'))[_0x3c3b('0x2e')](0x3e8, function() {
            $(this)[_0x3c3b('0x45')](_0x58d1cc[_0xbb05bc]);
            $(this)[_0x3c3b('0x31')]('fast');
        });
        TweenMax['to'](_0x3787f5, 0x1, {
            'clipPath': 'circle(' + _0x3a2e45 + _0x3c3b('0x46'),
            'webkitClipPath': _0x3c3b('0x47') + _0x3a2e45 + '%\x20at\x2050%\x20100%)',
            'ease': Power2[_0x3c3b('0x1b')],
            'onComplete': function() {
                _0x37a7aa[_0x3c3b('0x48')]();
                TweenMax[_0x3c3b('0xa')](_0x37a7aa[_0x3c3b('0x49')]('.slidebg'), {
                    'scale': 1.5
                });
                TweenMax[_0x3c3b('0xa')](_0x37a7aa[_0x3c3b('0x49')]('.slidecontent\x20h2\x20.hrow\x20span'), {
                    'y': 0x7d
                });
                if (_0x2504d4) {
                    TweenMax[_0x3c3b('0xa')](_0x37a7aa[_0x3c3b('0x49')](_0x3c3b('0x4a')), {
                        'y': 0x1e,
                        'opacity': 0x0
                    });
                }
                TweenMax[_0x3c3b('0xa')](_0x37a7aa[_0x3c3b('0x49')](_0x3c3b('0x4b')), {
                    'y': 0x14,
                    'opacity': 0x0
                });
                _0x37a7aa[_0x3c3b('0x49')](_0x3c3b('0x4c'))['css']({
                    'opacity': 0x0
                });
                _0x37a7aa = _0x3787f5;
                _0x4ee16b();
                _0x4f7f8b();
            }
        });
        TweenMax['to']($('.slides\x20.slide')['eq'](_0xbb05bc)[_0x3c3b('0x49')](_0x3c3b('0x4d')), 0x3, {
            'scale': 0x1,
            'ease': Power3[_0x3c3b('0x4e')]
        });
        console['log'](_0xbb05bc);
    }

    function _0x1509c1() {
        if (_0xbb05bc == 0x0) _0xbb05bc = _0xacb126;
        _0xbb05bc--;
        $(_0x3c3b('0x40'))['eq'](_0xbb05bc)[_0x3c3b('0x41')](_0x3c3b('0x42'))[_0x3c3b('0x4f')]()[_0x3c3b('0x43')]('active');
        _0x3787f5 = $(_0x3c3b('0x25'))['eq'](_0xbb05bc);
        _0x341cf6(_0x3787f5, 0x0);
        _0x25de6b(_0x3787f5);
        $(_0x3c3b('0x44'))['fadeOut'](0x3e8, function() {
            $(this)[_0x3c3b('0x45')](_0x58d1cc[_0xbb05bc]);
            $(this)[_0x3c3b('0x31')](_0x3c3b('0x2f'));
        });
        TweenMax['to'](_0x3787f5, 0x1, {
            'clipPath': _0x3c3b('0x47') + _0x3a2e45 + _0x3c3b('0x50'),
            'webkitClipPath': _0x3c3b('0x47') + _0x3a2e45 + _0x3c3b('0x50'),
            'ease': Power2[_0x3c3b('0x1b')],
            'onComplete': function() {
                _0x37a7aa[_0x3c3b('0x48')]();
                TweenMax[_0x3c3b('0xa')](_0x37a7aa[_0x3c3b('0x49')](_0x3c3b('0x4d')), {
                    'scale': 1.5
                });
                _0x37a7aa[_0x3c3b('0x49')](_0x3c3b('0x4c'))[_0x3c3b('0x51')]({
                    'opacity': 0x0
                });
                TweenMax[_0x3c3b('0xa')](_0x37a7aa[_0x3c3b('0x49')](_0x3c3b('0x4a')), {
                    'y': 0x7d
                });
                if (_0x2504d4) {
                    TweenMax[_0x3c3b('0xa')](_0x37a7aa[_0x3c3b('0x49')](_0x3c3b('0x4a')), {
                        'y': 0x1e,
                        'opacity': 0x0
                    });
                }
                TweenMax[_0x3c3b('0xa')](_0x37a7aa[_0x3c3b('0x49')]('.slidecontent\x20.sdesc,.cta'), {
                    'y': 0x14,
                    'opacity': 0x0
                });
                _0x37a7aa = _0x3787f5;
                _0x4ee16b();
                _0x4f7f8b();
            }
        });
        TweenMax['to']($(_0x3c3b('0x25'))['eq'](_0xbb05bc)[_0x3c3b('0x49')](_0x3c3b('0x4d')), 0x3, {
            'scale': 0x1,
            'ease': Power3[_0x3c3b('0x4e')]
        });
        console['log'](_0xbb05bc);
    }

    function _0x4ee16b() {
        $(_0x3c3b('0x25'))[_0x3c3b('0x51')]({
            'clip-path': 'none'
        });
    }

    function _0x341cf6(_0x4db43e, _0x10b9c5) {
        var _0x14dc80;
        if (_0x10b9c5 == 0x0) _0x14dc80 = 0x0;
        if (_0x10b9c5 == 0x1) _0x14dc80 = 0x64;
        _0x4db43e[_0x3c3b('0x51')]({
            'clip-path': _0x3c3b('0x52') + _0x14dc80 + '%)',
            '-webkit-clip-path': _0x3c3b('0x52') + _0x14dc80 + '%)'
        });
    }

    function _0x25de6b(_0x4d7f0c) {
        $(_0x3c3b('0x25'))[_0x3c3b('0x51')]({
            'z-index': 0xa
        });
        $(_0x3c3b('0x25'))[_0x3c3b('0x48')]();
        _0x37a7aa[_0x3c3b('0x53')]();
        _0x4d7f0c['show']();
        _0x4d7f0c['css']({
            'z-index': 0xb
        });
    }
    $(_0x3c3b('0x40'))['on']('click', function() {
        if (_0xbb05bc != $(this)[_0x3c3b('0x54')](_0x3c3b('0x55'))) {
            _0xbb05bc = parseInt($(this)[_0x3c3b('0x54')]('rel')) - 0x1;
            _0x3d72b6();
        }
    });

    function _0x4f7f8b() {
        TweenMax['to']($(_0x3c3b('0x56')), 0x1, {
            'rotationZ': '360deg',
            'ease': Power3[_0x3c3b('0x1b')],
            'onComplete': function() {
                TweenMax[_0x3c3b('0xa')]($('.header\x20.logo'), {
                    'rotationZ': '0deg'
                });
            }
        });
        if (_0xbb05bc == 0x1 || _0xbb05bc == 0x3 || _0xbb05bc == 0x5 || _0xbb05bc == 0x7) {
            $(_0x3c3b('0x57'))['addClass'](_0x3c3b('0x58'));
        } else {
            $(_0x3c3b('0x57'))[_0x3c3b('0x43')](_0x3c3b('0x58'));
        }
        var _0x49bf0d = $(_0x3c3b('0x25'))['eq'](_0xbb05bc)[_0x3c3b('0x49')](_0x3c3b('0x59'));
        var _0x22d012 = _0x49bf0d[_0x3c3b('0x49')](_0x3c3b('0x5a'));
        _0x49bf0d[_0x3c3b('0x49')](_0x3c3b('0x5b'))[_0x3c3b('0x5c')](_0x3c3b('0x5d'));
        var _0x53d5b9 = _0x49bf0d[_0x3c3b('0x49')]('.ssection\x20.blok');
        TweenMax['to'](_0x53d5b9, 0.3, {
            'scaleX': '1',
            'onComplete': function() {
                _0x22d012[_0x3c3b('0x51')]({
                    'opacity': 0x1
                });
                _0x53d5b9[_0x3c3b('0x51')]({
                    'transformOrigin': _0x3c3b('0x5e')
                });
                TweenMax['to'](_0x53d5b9, 0.3, {
                    'scaleX': '0',
                    'ease': Power4['easeOut'],
                    'onComplete': function() {
                        _0x53d5b9[_0x3c3b('0x1c')]();
                    }
                });
            },
            'ease': Power4[_0x3c3b('0x4e')]
        });
        var _0x29e506 = _0x49bf0d[_0x3c3b('0x49')](_0x3c3b('0x5f'));
        var _0x328d54 = _0x49bf0d[_0x3c3b('0x49')](_0x3c3b('0x5f'))[_0x3c3b('0x60')];
        for (var _0x1c08ba = 0x0; _0x1c08ba < _0x328d54; _0x1c08ba++) {
            TweenMax['to'](_0x29e506[_0x1c08ba], 0x1, {
                'y': 0x0,
                'opacity': 0x1,
                'delay': _0x1c08ba * 0.2 + 0.2,
                'ease': Power2[_0x3c3b('0x1b')]
            });
        }
        TweenMax['to'](_0x49bf0d[_0x3c3b('0x49')](_0x3c3b('0x61')), 0x1, {
            'opacity': 0x1,
            'y': 0x0,
            'delay': 1.5,
            'ease': Power2[_0x3c3b('0x4e')]
        });
        TweenMax['to'](_0x49bf0d[_0x3c3b('0x49')](_0x3c3b('0x62')), 0x1, {
            'opacity': 0x1,
            'y': 0x0,
            'delay': 1.7,
            'ease': Power2[_0x3c3b('0x4e')]
        });
    }
    $(_0x3c3b('0x63'))['on'](_0x3c3b('0x2d'), function(_0x487873) {
        var _0x1c8116 = $(this)[_0x3c3b('0x54')](_0x3c3b('0x55'));
        _0x1efd65(_0x1c8116, _0x1c8116 + _0x3c3b('0x64'));
        _0x487873[_0x3c3b('0x65')]();
        _0x48b398(_0x1c8116);
    });
    TweenMax[_0x3c3b('0xa')]($(_0x3c3b('0x66')), {
        'x': _0x3c3b('0x67')
    });

    function _0x48b398(_0x61fbce) {
        _0x49f127 = 'type1';
        $(_0x3c3b('0x68'))[_0x3c3b('0x53')]();
        TweenMax['to']($(_0x3c3b('0x68')), 0.6, {
            'opacity': 0x1,
            'delay': 0.5
        });
        TweenMax['to']($(_0x3c3b('0x69')), 0x2, {
            'scale': 0x1
        });
        TweenMax['to']($(_0x3c3b('0x6a')), 0x1, {
            'x': '+=' + (0x442 + _0x5074e4) + 'px',
            'ease': Power3['easeInOut'],
            'onComplete': function() {
                _0x537ebf(_0x61fbce);
            }
        });
    }

    function _0x537ebf(_0x37ffab) {
        $(_0x3c3b('0x6b'))[_0x3c3b('0x43')](_0x3c3b('0x6c'));
        $('.inner')['addClass'](_0x37ffab);
        TweenMax['to'](_0x3c3b('0x6d'), 0.3, {
            'opacity': 0x1
        });
        $[_0x3c3b('0x6e')]({
            'method': _0x3c3b('0x6f'),
            'url': _0x37ffab + _0x3c3b('0x70'),
            'data': {
                'name': _0x3c3b('0x71'),
                'location': _0x3c3b('0x72')
            }
        })[_0x3c3b('0x73')](function(_0x5d3bc4) {
            TweenMax['to']($('.transitionmask2\x20img'), 0x1, {
                'x': '+=' + (0x442 + _0x5074e4) + 'px',
                'ease': Power3[_0x3c3b('0x1b')],
                'onComplete': function() {
                    $(_0x3c3b('0x6b'))[_0x3c3b('0x53')]();
                    $(_0x3c3b('0x6b'))[_0x3c3b('0x27')](_0x5d3bc4);
                    TweenMax[_0x3c3b('0xa')]($(_0x3c3b('0x68')), {
                        'scale': 1.4,
                        'opacity': 0x0,
                        'onComplete': function() {
                            $(_0x3c3b('0x68'))[_0x3c3b('0x48')]();
                        }
                    });
                    _0x55fc08();
                    _0x3cd839('/' + _0x37ffab + _0x3c3b('0x64'), _0x37ffab);
                }
            });
        });
    }
    $(_0x3c3b('0x6d'))['on'](_0x3c3b('0x2d'), function() {
        history[_0x3c3b('0x74')]();
    });

    function _0x55fc08() {
        $(_0x3c3b('0x75'))[_0x3c3b('0x51')]({
            'opacity': 0x1,
            'transform': _0x3c3b('0x76')
        });
        setTimeout(function() {
            $(_0x3c3b('0x77'))[_0x3c3b('0x41')](_0x3c3b('0x78'));
        }, 0x190);
        TweenMax['to']($(_0x3c3b('0x77')), 0.7, {
            'delay': 2.2,
            'y': '100%',
            'ease': Power3[_0x3c3b('0x1b')],
            'onComplete': function() {
                $('.innerswipe_base')['remove']();
                TweenMax[_0x3c3b('0x79')]($(_0x3c3b('0x7a')), 0x1, {
                    'opacity': 0x1,
                    'y': 0x0
                }, 0.1);
            }
        });
    }

    function _0x278d5d() {
        TweenMax['to'](_0x3c3b('0x6d'), 0.3, {
            'opacity': 0x0
        });
        $(_0x3c3b('0x6b'))[_0x3c3b('0x2e')](_0x3c3b('0x2f'), function() {
            $(_0x3c3b('0x6b'))[_0x3c3b('0x27')]('');
            TweenMax['to']($(_0x3c3b('0x6a')), 0x1, {
                'x': _0x3c3b('0x67'),
                'delay': 0.4,
                'ease': Power3[_0x3c3b('0x1b')]
            });
            TweenMax['to']($('.transitionmask2\x20img'), 0x1, {
                'x': _0x3c3b('0x67'),
                'ease': Power3[_0x3c3b('0x1b')]
            });
        });
    }

    function _0x2a0afd() {
        _0x49f127 = 'type2';
        TweenMax['to'](_0x3c3b('0x7b'), 0.3, {
            'opacity': 0x1,
            'y': 0x0,
            'delay': 0x2
        });
        TweenMax['to']($('.workmask'), 0x1, {
            'scaleX': 0x1,
            'ease': Power3[_0x3c3b('0x1b')],
            'onComplete': function() {
                $[_0x3c3b('0x6e')]({
                    'method': 'POST',
                    'url': _0x3c3b('0x7c'),
                    'data': {
                        'name': _0x3c3b('0x71'),
                        'location': _0x3c3b('0x72')
                    }
                })[_0x3c3b('0x73')](function(_0x141a88) {
                    $(_0x3c3b('0x7d'))[_0x3c3b('0x53')]();
                    $('.inner-work')[_0x3c3b('0x27')](_0x141a88);
                    var _0x256ffb = $('.case-study-grid')[_0x3c3b('0x7e')]({
                        'itemSelector': _0x3c3b('0x7f'),
                        'columnWidth': _0x3c3b('0x80'),
                        'percentPosition': !![],
                        'gutter': 0x14
                    });
                    _0x256ffb[_0x3c3b('0x81')]()[_0x3c3b('0x82')](function() {
                        _0x256ffb['masonry']('layout');
                    });
                    $(_0x3c3b('0x7f'))['on']('click', function() {
                        var _0x53fe06 = $(this)[_0x3c3b('0x54')](_0x3c3b('0x83'));
                        var _0x34bc1f = $(this)['attr'](_0x3c3b('0x84'));
                        _0x581e6e(_0x53fe06, _0x34bc1f);
                    });
                    _0x3cd839(_0x3c3b('0x85'), _0x3c3b('0x86'));
                    TweenMax['fromTo']($(_0x3c3b('0x87')), 0.5, {
                        'opacity': 0x0,
                        'y': '+=30'
                    }, {
                        'opacity': 0x1,
                        'y': 0x0
                    });
                    TweenMax[_0x3c3b('0x29')]($(_0x3c3b('0x88')), 0.5, {
                        'opacity': 0x0,
                        'y': _0x3c3b('0x89')
                    }, {
                        'opacity': 0x1,
                        'y': 0x0,
                        'delay': 0.5
                    });
                });
            }
        });
    }
    $('.menu-btn')['on'](_0x3c3b('0x2d'), function() {
        $(this)[_0x3c3b('0x8a')](_0x3c3b('0x42'));
        $('.menuoverlay')[_0x3c3b('0x8a')]('open');
    });
    $(_0x3c3b('0x8b'))['on'](_0x3c3b('0x2d'), function() {
        $('.menuoverlay')[_0x3c3b('0x8a')](_0x3c3b('0x8c'));
        $('.menu-btn')[_0x3c3b('0x8a')](_0x3c3b('0x42'));
        var _0xbadc64 = $(this)['attr']('rel');
        switch (_0xbadc64) {
            case _0x3c3b('0x8d'):
                _0x1efd65(_0xbadc64, _0xbadc64 + _0x3c3b('0x64'));
                _0x2a0afd();
                break;
            case _0x3c3b('0x8e'):
                _0x1efd65(_0xbadc64, _0xbadc64 + _0x3c3b('0x64'));
                _0x48b398(_0xbadc64);
                break;
            case _0x3c3b('0x8f'):
                _0x1efd65(_0xbadc64, _0xbadc64 + _0x3c3b('0x64'));
                _0x48b398(_0xbadc64);
                break;
            case 'motion_graphics':
                _0x1efd65(_0xbadc64, _0xbadc64 + _0x3c3b('0x64'));
                _0x48b398(_0xbadc64);
                break;
            case _0x3c3b('0x90'):
                _0x1efd65(_0xbadc64, _0xbadc64 + _0x3c3b('0x64'));
                _0x48b398(_0xbadc64);
                break;
            case _0x3c3b('0x91'):
                _0x1efd65(_0xbadc64, _0xbadc64 + _0x3c3b('0x64'));
                _0x48b398(_0xbadc64);
                break;
            case _0x3c3b('0x92'):
                _0x1efd65(_0xbadc64, _0xbadc64 + _0x3c3b('0x64'));
                _0x48b398(_0xbadc64);
                break;
            case _0x3c3b('0x93'):
                _0x1efd65(_0xbadc64, _0xbadc64 + _0x3c3b('0x64'));
                _0xd9d316();
                break;
            case _0x3c3b('0x94'):
                _0x1efd65(_0xbadc64, _0xbadc64 + '.htm');
                _0x48b398(_0xbadc64);
                break;
            default:
        }
    });
    $(_0x3c3b('0x95'))['on'](_0x3c3b('0x2d'), function() {
        history[_0x3c3b('0x74')]();
    });

    function _0xd9d316() {
        _0x49f127 = 'type3';
        $(_0x3c3b('0x96'))[_0x3c3b('0x31')]('fast');
        $('.contactpopup')[_0x3c3b('0x97')](0x64)[_0x3c3b('0x31')](_0x3c3b('0x2f'));
        _0x3cd839(_0x3c3b('0x98'), _0x3c3b('0x99'));
    }

    function _0x1755cc() {
        $(_0x3c3b('0x9a'))[_0x3c3b('0x2e')](_0x3c3b('0x2f'));
        $('.contactpopupbg')[_0x3c3b('0x97')](0x64)[_0x3c3b('0x2e')](_0x3c3b('0x2f'));
    }
    $(_0x3c3b('0x9b'))['on'](_0x3c3b('0x2d'), function(_0x3a7f74) {
        _0x3a7f74[_0x3c3b('0x65')]();
        $(_0x3c3b('0x9c'))[_0x3c3b('0x27')]('');
        var _0x2fb8cc = 0x0;
        var _0x19a6cd = $(_0x3c3b('0x9d'))[_0x3c3b('0x9e')]();
        var _0xf3052d = $(_0x3c3b('0x9f'))['val']();
        var _0x3a3837 = /^\w+([-+.'][^\s]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
        var _0x4d21d5 = _0x3a3837[_0x3c3b('0xa0')](_0xf3052d);
        if (_0x19a6cd == '') {
            $('.er_fname')[_0x3c3b('0x27')](_0x3c3b('0xa1'));
            _0x2fb8cc = 0x1;
        }
        if (_0xf3052d == '') {
            $(_0x3c3b('0xa2'))['html'](_0x3c3b('0xa3'));
            _0x2fb8cc = 0x1;
        } else if (!_0x4d21d5) {
            $(_0x3c3b('0xa2'))[_0x3c3b('0x27')]('Please\x20enter\x20a\x20valid\x20email');
            _0x2fb8cc = 0x1;
        }
        if (_0x2fb8cc == 0x0) {
            var _0x21b1f8 = $(_0x3c3b('0xa4'))[_0x3c3b('0xa5')]();
            console[_0x3c3b('0x11')](_0x21b1f8);
            $[_0x3c3b('0x6e')]({
                'method': _0x3c3b('0x6f'),
                'url': _0x3c3b('0xa6'),
                'data': _0x21b1f8
            })['done'](function(_0x39e1d9) {
                if (_0x39e1d9 == _0x3c3b('0xa7')) {
                    $(_0x3c3b('0xa4'))['trigger'](_0x3c3b('0xa8'));
                    $(_0x3c3b('0xa9'))[_0x3c3b('0x31')](_0x3c3b('0x32'));
                    setTimeout(function() {
                        history['back']();
                    }, 0xbb8);
                }
            });
        }
    });
    $(_0x3c3b('0x7b'))['on'](_0x3c3b('0x2d'), function() {
        history[_0x3c3b('0x74')]();
    });
    $(_0x3c3b('0xaa'))['on']('click', function() {
        history['back']();
    });

    function _0x1cc9fe() {
        TweenMax['to'](_0x3c3b('0x7b'), 0.3, {
            'opacity': 0x0,
            'y': _0x3c3b('0xab')
        });
        $(_0x3c3b('0x7d'))[_0x3c3b('0x2e')](_0x3c3b('0x2f'), function() {
            $(_0x3c3b('0x7d'))[_0x3c3b('0x27')]('');
            TweenMax['to']($(_0x3c3b('0xac')), 0x1, {
                'scaleX': 0x0,
                'delay': 0.4,
                'ease': Power3[_0x3c3b('0x1b')]
            });
        });
    }

    function _0x17d1c8() {
        TweenMax['to'](_0x3c3b('0xaa'), 0.3, {
            'opacity': 0x0,
            'y': _0x3c3b('0xab')
        });
        TweenMax['to']($(_0x3c3b('0xad')), 0x1, {
            'scaleX': 0x1,
            'ease': Power3[_0x3c3b('0x1b')],
            'onComplete': function() {
                $(_0x3c3b('0xae'))[_0x3c3b('0x48')]();
                $(_0x3c3b('0xae'))[_0x3c3b('0x27')]('');
                TweenMax['to']($(_0x3c3b('0xad')), 0x1, {
                    'scaleX': 0x0,
                    'delay': 0.4,
                    'ease': Power3[_0x3c3b('0x1b')]
                });
            }
        });
    }

    function _0x581e6e(_0x237b00, _0x2d9dbc) {
        _0x49f127 = _0x3c3b('0x19');
        _0x1efd65(_0x2d9dbc, _0x3c3b('0xaf') + _0x2d9dbc);
        TweenMax['to'](_0x3c3b('0xaa'), 0.3, {
            'opacity': 0x1,
            'y': 0x0,
            'delay': 0x2
        });
        TweenMax['to']($(_0x3c3b('0xad')), 0x1, {
            'scaleX': 0x1,
            'ease': Power3[_0x3c3b('0x1b')],
            'onComplete': function() {
                $['ajax']({
                    'method': _0x3c3b('0x6f'),
                    'url': _0x3c3b('0xb0'),
                    'data': {
                        'id': _0x237b00,
                        'location': _0x3c3b('0x72')
                    }
                })['done'](function(_0x151dd1) {
                    TweenMax['to']($('.detailmask'), 0x1, {
                        'scaleX': 0x0,
                        'ease': Power3[_0x3c3b('0x1b')]
                    });
                    $(_0x3c3b('0xae'))[_0x3c3b('0x53')]();
                    $(_0x3c3b('0xae'))[_0x3c3b('0x27')](_0x151dd1);
                    var _0x1bcf99 = new Swiper(_0x3c3b('0xb1'), {
                        'direction': _0x3c3b('0xb2'),
                        'effect': _0x3c3b('0xb3'),
                        'autoplay': {
                            'delay': 0x7d0
                        },
                        'cubeEffect': {
                            'shadow': ![]
                        },
                        'loop': !![]
                    });
                });
            }
        });
    }
});